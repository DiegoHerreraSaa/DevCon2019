<?php
require_once('../includes/funciones/bd_conexion.php');
require_once('../includes/funciones/funciones.php');