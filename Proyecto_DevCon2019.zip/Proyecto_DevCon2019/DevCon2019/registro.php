<?php include_once 'includes/templates/header.php' ?>

<section class="seccion contenedor">
    <h2>Registro de Usuarios</h2>

    <form action="pagar.php" id="registro" class="registro" method="POST">

        <div id="datos_usuario" class="registro caja clearfix">

            <div class="campo">
                <label for="nombre">Nombre: </label>
                <input type="text" id="nombre" name="nombre" placeholder="Escribe tu nombre.">
            </div>

            <div class="campo">
                <label for="apellido">Apellido: </label>
                <input type="text" id="apellido" name="apellido" placeholder="Escribe tu apellido.">
            </div>

            <div class="campo">
                <label for="email">E-mail: </label>
                <input type="text" id="email" name="email" placeholder="Escribe tu email.">
            </div>

            <div id="error"></div>

        </div> <!-- #datos_usuario -->

        <div id="paquetes" class="paquetes">
            <h3>Elige el número de boletos</h3>

            <ul class="lista-precios clearfix">
                <li>
                    <div class="tabla-precio">
                        <h3>Pase por día (viernes)</h3>
                        <p class="numero">$30</p>
                        <ul>
                            <li><i class="fas fa-check"></i> Pasabocas gratis</li>
                            <li><i class="fas fa-check"></i> Todas las conferencias</li>
                            <li><i class="fas fa-check"></i> Todos los talleres</li>
                        </ul>
                        <div class="orden">
                            <label for="pase_dia">Cantidad: </label>
                            <input type="number" min='0' id="pase_dia" size="3" name="boletos[un_dia][cantidad]" placeholder="0">
                            <input type="hidden" name="boletos[un_dia][precio]" value="30">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="tabla-precio">
                        <h3>Todos los días</h3>
                        <p class="numero">$50</p>
                        <ul>
                            <li><i class="fas fa-check"></i> Pasabocas gratis</li>
                            <li><i class="fas fa-check"></i> Todas las conferencias</li>
                            <li><i class="fas fa-check"></i> Todos los talleres</li>
                        </ul>
                        <div class="orden">
                            <label for="pase_completo">Cantidad: </label>
                            <input type="number" min='0' id="pase_completo" size="3" name="boletos[completo][cantidad]" placeholder="0">
                            <input type="hidden" name="boletos[completo][precio]" value="50">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="tabla-precio">
                        <h3>Pase por 2 días (viernes y sábado)</h3>
                        <p class="numero">$45</p>
                        <ul>
                            <li><i class="fas fa-check"></i> Pasabocas gratis</li>
                            <li><i class="fas fa-check"></i> Todas las conferencias</li>
                            <li><i class="fas fa-check"></i> Todos los talleres</li>
                        </ul>
                        <div class="orden">
                            <label for="pase_dosdias">Cantidad: </label>
                            <input type="number" min='0' id="pase_dosdias" size="3" name="boletos[2dias][cantidad]" placeholder="0">
                            <input type="hidden" name="boletos[2dias][precio]" value="45">
                        </div>
                    </div>
                </li>

            </ul>


        </div> <!-- #paquetes -->

        <div id="eventos" class="eventos clearfix">
            <h3>Elige tus talleres</h3>
            <div class="caja">
                <?php
                try {
                    require_once('includes/funciones/bd_conexion.php');
                    $sql = " SELECT eventos.*, categoria_evento.cat_evento, invitados.nombre_invitado, invitados.apellido_invitado ";
                    $sql .= " FROM eventos ";
                    $sql .= " JOIN categoria_evento ";
                    $sql .= " ON eventos.id_categoria = categoria_evento.id_categoria ";
                    $sql .= " JOIN invitados ";
                    $sql .= " ON eventos.id_invitado = invitados.id_invitado ";
                    $sql .= " ORDER BY eventos.fecha_evento, eventos.id_categoria, eventos.hora_evento ";
                    // echo $sql;
                    $resultado = $conn->query($sql);
                } catch (Exception $e) {
                    echo $e->getMessage();
                }

                // Clase 477
                $eventos_dias = array();
                while ($eventos = $resultado->fetch_assoc()) {

                    $fecha = $eventos['fecha_evento'];
                    setlocale(LC_ALL, 'es_ES');
                    $dia_semana = strftime("%A", strtotime($fecha));

                    $categoria = $eventos['cat_evento'];
                    $dia = array(
                        'nombre_evento' => $eventos['nombre_evento'],
                        'hora' => $eventos['hora_evento'],
                        'id' => $eventos['id_evento'],
                        'nombre_invitado' => $eventos['nombre_invitado'],
                        'apellido_invitado' => $eventos['apellido_invitado']
                    );
                    $eventos_dias[$dia_semana]['eventos'][$categoria][] = $dia;
                }
                // echo '<pre>';
                // var_dump($eventos_dias);
                // echo '</pre>';
                ?>

                <?php foreach ($eventos_dias as $dia => $eventos) { ?>
                    <div id="<?php echo str_replace('á', 'a', $dia); ?>" class="contenido-dia clearfix">
                        <h4><?php echo $dia; ?></h4>
                        <?php
                        // echo '<pre>';
                        // var_dump($eventos);
                        // echo '</pre>'
                        foreach ($eventos['eventos'] as $tipo => $evento_deldia) : ?>
                            <div>
                                <p><?php echo $tipo; ?>:</p>
                                <?php
                                // echo '<pre>';
                                // var_dump($evento_deldia);
                                // echo '</pre>'
                                foreach ($evento_deldia as $evento) { ?>
                                    <label>
                                        <input type="checkbox" name="registro[]" id="<?php echo $evento['id']; ?>" value="<?php echo $evento['id']; ?>">
                                        <time><?php echo $evento['hora']; ?></time> <?php echo $evento['nombre_evento']; ?>
                                        <br>
                                        <span class="autor"><?php echo $evento['nombre_invitado'] . " " . $evento['apellido_invitado']; ?></span>
                                    </label>
                                <?php } ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <!-- .contenido-dia -->
                <?php } ?>
            </div>
            <!--.caja-->
        </div>
        <!--#eventos-->

        <div id="resumen" class="resumen">
            <h3>Pago y Extras</h3>
            <div class="caja clearfix">
                <div class="extras">
                    <div class="orden">
                        <label for="camisa_evento">Camisa del evento $10 <small>(promoción 7% dcto.)</small></label> <br>
                        <input type="number" min='0' id='camisa_evento' size="3" name="pedido_extra[camisas][cantidad]" placeholder="0">
                        <input type="hidden" name="pedido_extra[camisas][precio]" value="10">
                    </div> <!-- .orden -->

                    <div class="orden">
                        <label for="etiquetas">Paquete de 10 etiquetas $3 <small>(HTML5, CSS3, JavaScript, Chrome)</small></label>
                        <input type="number" min='0' id='etiquetas' size="3" name="pedido_extra[etiquetas][cantidad]" placeholder="0">
                        <input type="hidden" name="pedido_extra[etiquetas][precio]" value="3">
                    </div> <!-- .orden -->

                    <div class="orden">
                        <label for="regalo">Selecciona el regalo</label> <br>
                        <select id="regalo" name="regalo" required>
                            <option value="">-- Selecciona un regalo --</option>
                            <!--los numeros hacen referencia a los que estan en la BD -->
                            <option value="1">Pulseras</option>
                            <option value="2">Etiquetas</option>
                            <option value="3">Plumas</option>
                        </select>
                    </div> <!-- .orden -->

                    <input type="button" id='calcular' class="boton" value="Calcular">

                </div> <!-- .extras -->

                <div class="total">
                    <p>Resumen:</p>
                    <div id="lista-productos">

                    </div>
                    <p>Total:</p>
                    <div id="suma-total">

                    </div>
                    <input type="hidden" name="total_pedido" id="total_pedido">
                    <input id="btnRegistro" type="submit" class="boton" name="submit" value='Pagar'>
                </div>
                <!--.total-->
            </div>
            <!--.caja-->
        </div>
        <!--#resumen-->

    </form>
    <!--#registro-->

</section>


<?php include_once 'includes/templates/footer.php' ?>