(function () {
    'use strict';

    var regalo = document.getElementById('regalo');
    document.addEventListener('DOMContentLoaded', function () {
        
        // Campos Datos usuario

        var nombre = document.getElementById('nombre');
        var apellido = document.getElementById('apellido');
        var email = document.getElementById('email');


        // Campos pases

        var pase_dia = document.getElementById('pase_dia');
        var pase_dosdias = document.getElementById('pase_dosdias');
        var pase_completo = document.getElementById('pase_completo');

        // Botones y divs

        var calcular = document.getElementById('calcular');
        var errorDiv = document.getElementById('error');
        var botonRegistro = document.getElementById('btnRegistro');
        var lista_productos = document.getElementById('lista-productos');
        var suma = document.getElementById('suma-total');

        // Extras

        var camisas = document.getElementById('camisa_evento');
        var etiquetas = document.getElementById('etiquetas');

        if(document.getElementById('registro')){
            botonRegistro.disabled = true;
        }

        if(document.getElementById('guardar-registro')){
            botonRegistro.disabled = true;
        }

        if (document.getElementById('calcular')) {


            calcular.addEventListener('click', calcularMontos); // el atributo addEventListener va a activar un evento cuando se haga click en el  
            // boton, este generará una funcion, osea que reaccione a un estimulo que es el click
            // la cual va a calcular todo el precio de lo adquirido en la pagina 
            // el valor 'click' contabiliza el numero de clicks que se dan en el boton

            pase_dia.addEventListener('input', mostrarDias); // a diferencia del click, si el usuario introduce el numero sin utilizar el click
            // el blur hace que se quede el valor que introduce el usuario
            pase_dosdias.addEventListener('input', mostrarDias);
            pase_completo.addEventListener('input', mostrarDias);


            nombre.addEventListener('blur', validarCampos);
            apellido.addEventListener('blur', validarCampos);
            email.addEventListener('blur', validarCampos);
            email.addEventListener('blur', validarEmail);

            var formulario_editar = document.getElementsByClassName('editar-registrado');
            if(formulario_editar.length > 0) {
                if(pase_dia.value || pase_dosdias.value || pase_completo.value ) {
                    mostrarDias();
                }
            }


            function validarCampos() {
                if (this.value === '') {
                    errorDiv.style.display = 'block';
                    errorDiv.innerHTML = '* Este campo es obligatorio';
                    this.style.border = '1px solid red';
                    errorDiv.style.color = 'red';
                    errorDiv.style.fontSize = '15px';
                } else {
                    this.style.border = '1px solid #A9A9A9';
                    //errorDiv.style.display = 'none';
                }
            }

            function validarEmail() {
                if (this.value.indexOf('@') <= -1) { /* recordemos que el atributo indexOf me verifica si "en este caso" exites un caracter @ en el 
                 texto introducido dentro del campo, este atributo nos devuelve un -1 en caso de que no lo encuentre */
                    errorDiv.style.display = 'block';
                    errorDiv.innerHTML = '* El campo E-mail debe contener un @';
                    this.style.border = '1px solid red';
                    errorDiv.style.color = 'red';
                    errorDiv.style.fontSize = '15px';
                } else {
                    this.style.border = '1px solid #A9A9A9';
                    //errorDiv.style.display = 'none';
                }
            }


            // creamos la funcion de calcular montos para el addEventListener
            function calcularMontos(event) {
                event.preventDefault();
                if (regalo.value === '') {
                    alert('Debes escoger un regalo');
                    regalo.focus();
                } else {
                    var boletosDia = parseInt(pase_dia.value, 10) || 0,
                            boletos2dias = parseInt(pase_dosdias.value, 10) || 0,
                            boletoCompleto = parseInt(pase_completo.value, 10) || 0,
                            cantCamisas = parseInt(camisas.value, 10) || 0,
                            cantEtiquetas = parseInt(etiquetas.value, 10) || 0;

                    /* este código parseInt(pase_dia.value, 10) || 0, 
                     
                     hace varias cosas, la primera; parseInt va a convertir el valor del <input> a numero (debido a que es un input que el usuario escribe, 
                     será string) o cadena, es decir, si ponen 20, no viene como 20, sino '20', parseInt lo convierte a un número que javascript pueda leer. 
                     
                     la segunda, es la parte del ,10, ese 10 es la base, es decir, conviertelo a base 10, que son los números del 0 al 9.
                     
                     la 3ra parte es la de:  || 0, en caso de que un usuario escriba HOLA!! nuestro código va a revisar, encontrar que estos no son números y va cambiar el texto HOLA!! por un 0. de esta forma, si el usuario escribe algo no deseado, evitamos errores, como querer hacer la operación con letras en lugar de números*/

                    var totalPagar = (boletosDia * 30) + (boletos2dias * 45) + (boletoCompleto * 50) + ((cantCamisas * 10) * 0.93) + (cantEtiquetas * 3);
                    //console.log(totalPagar);

                    var listadoProductos = []; // aqui vamos a crear un array, tambien se puede colocar como new Array(), Array() o [];
                    // en este espacio vamos a imprimir lo que la persona seleccione de los productos

                    if (boletosDia >= 1) {
                        listadoProductos.push('Pases por día: ' + boletosDia + ' x $30');
                    }
                    if (boletos2dias >= 1) {
                        listadoProductos.push('Pases por 2 días: ' + boletos2dias + ' x $45');
                    }
                    if (boletoCompleto >= 1) {
                        listadoProductos.push('Pases Completos: ' + boletoCompleto + ' x $50');
                    }
                    if (cantCamisas >= 1) {
                        listadoProductos.push('Camisas: ' + cantCamisas + ' x $10 (- 7%)');
                    }
                    if (cantEtiquetas >= 1) {
                        listadoProductos.push('Etiquetas: ' + cantEtiquetas + ' x $3');
                    }

                    lista_productos.style.display = 'block';

                    lista_productos.innerHTML = '';
                    for (var i = 0; i < listadoProductos.length; i++) {
                        lista_productos.innerHTML += listadoProductos[i] + '<br/>';
                    }
                    suma.innerHTML = '$ ' + totalPagar.toFixed(2); // el atributo toFixed sirve para limitar el numero de decimales

                    botonRegistro.disabled = false;
                    document.getElementById('total_pedido').value = totalPagar;

                }
            }



            function mostrarDias() {
                var boletosDia = parseInt(pase_dia.value, 10) || 0,
                        boletos2dias = parseInt(pase_dosdias.value, 10) || 0,
                        boletoCompleto = parseInt(pase_completo.value, 10) || 0;

                var diasElegidos = [];

                if (boletosDia > 0) {
                    diasElegidos.push('viernes');
                }
                if (boletos2dias > 0) {
                    diasElegidos.push('viernes', 'sabado');
                }
                if (boletoCompleto > 0) {
                    diasElegidos.push('viernes', 'sabado', 'domingo');
                }
                for (var i = 0; i < diasElegidos.length; i++) {
                    document.getElementById(diasElegidos[i]).style.display = 'block';
                }
            }


        }
    });  // DOM CONTENT LOADED
})();