<?php // Clase 455
    include_once 'funciones/funciones.php';

    // variables que se envían
    if(isset($_POST['nombre_categoria'])){
        $nombre_categoria = $_POST['nombre_categoria'];
        $icono = $_POST['icono'];
    }

if ($_POST["registro"] == 'nuevo') {
    // die(json_encode($_POST));

    try {
        // preparo la inserción de datos
    $stmt = $conn->prepare("INSERT INTO categoria_evento (cat_evento, icono) VALUES (?, ?)");
        // envío los datos con bind_param
    $stmt->bind_param("ss", $nombre_categoria, $icono );
    $stmt->execute();
    $id_insertado = $stmt->insert_id;
    if($stmt->affected_rows){
        $respuesta = array(
            'respuesta' => 'exito',
            'id_insertado' => $id_insertado
        );
    } else {
        $respuesta = array(
            'respuesta' => 'error'
        );
    }
    $stmt->close();
    $conn->close();
    } catch (Exception $e) {
        $respuesta = array(
            'respuesta' => $e->getMessage()
        );
    }
    die(json_encode($respuesta));
}

/* ================================================================================================================== */

if ($_POST['registro'] == 'actualizar') {
    $id_registro = $_POST['id_registro'];

    // die(json_encode($_POST));

    try { 
        $stmt = $conn->prepare("UPDATE categoria_evento SET cat_evento = ?, icono = ?, editado = NOW() WHERE id_categoria = ? ");
        $stmt->bind_param("ssi", $nombre_categoria, $icono, $id_registro );
        $stmt->execute();
        if($stmt->affected_rows > 0){
            $respuesta = array(
                'respuesta' => 'exito',
                'id_actualizado' => $id_registro
            );
        } else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        $respuesta = array(
            'respuesta' => $e->getMessage()
        );
    }
    die(json_encode($respuesta));
}

/* ================================================================================================================== */

if ($_POST['registro'] == 'eliminar') {

    $id_borrar = $_POST['id']; // este id lo toma del admin-ajax linea 58

    try {
        $stmt = $conn->prepare("DELETE FROM categoria_evento WHERE id_categoria = ? ");
        $stmt->bind_param('i', $id_borrar);
        $stmt->execute();
        if($stmt->affected_rows) {
            $respuesta = array(
                'respuesta' => 'exito',
                'id_eliminado' => $id_borrar
            );
        } else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
    } catch (Exception $e) {
        $respuesta = array(
            'respuesta' => $e->getMessage()
        );
    }
    die(json_encode($respuesta));
}
