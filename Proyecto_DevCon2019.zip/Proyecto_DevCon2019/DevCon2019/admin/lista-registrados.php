<?php // Clase 473

include_once 'funciones/sesiones.php';

if($_SESSION['nivel'] == null) {
  die('Página no permitida.');
}

include_once 'funciones/funciones.php';
include_once 'templates/header.php';
include_once 'templates/barra.php';
include_once 'templates/navegacion.php';

?>



<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Listado de Personas Registradas
      <small></small>
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Administra todos los visitantes registrados al evento</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <table id="registros" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Email</th>
                  <th>Fecha Registro</th>
                  <th>Artículos</th>
                  <th>Talleres</th>
                  <th>Regalo</th>
                  <th>Compra</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                <?php
                try {
                    $sql = " SELECT registrados.*, regalos.nombre_regalo FROM registrados ";
                    $sql .= " JOIN regalos ";
                    $sql .= " ON registrados.regalo = regalos.id_regalo ";
                    // echo $sql; DEBUGEAR CÓDIGO
                    $resultado = $conn->query($sql);
                } catch (Exception $e) {
                  $error = $e->getMessage();
                  echo $error;
                }

                while ($registrado = $resultado->fetch_assoc()) {
                    // echo '<pre>';
                    //     var_dump($registrado);
                    // echo '</pre>';
                    ?>

                  <tr>
                    <td>
                        <?php echo $registrado['nombre_registrado'] . " " . $registrado['apellido_registrado'];
                            $pagado = $registrado['pagado'];
                            if($pagado){
                                echo '<span class="badge bg-green">Pagado</span>';
                            } else {
                                echo '<span class="badge bg-red">No pagado</span>';
                            }
                        ?>
                    </td>
                    <td><?php echo $registrado['email_registrado']; ?></td>
                    <td><?php echo $registrado['fecha_registrado'];?></td>
                    <td>
                        <?php
                        $articulos = json_decode($registrado['pases_articulos'], true);
                        $arreglo_articulos = array(
                            'un_dia' => 'Pase 1 día',
                            'pase2Dias' => 'Pase 2 días',
                            'paseCompleto' => 'Pase Completo',
                            'camisas' => 'Camisas',
                            'etiquetas' => 'Etiquetas'
                        );

                        foreach($articulos as $llave => $articulo) { // Clase 483
                        //  echo '<pre>';
                        //    var_dump($articulos);
                        //  echo '</pre>';
                          if(is_array($articulo) && array_key_exists('cantidad', $articulo)){
                            echo $articulo['cantidad'] . " " . $arreglo_articulos[$llave] . "<br>";
                          } else {
                            echo $articulo . " " . $arreglo_articulos[$llave] . "<br>";
                          }
                        }
                        // echo '<pre>';
                        //     var_dump($articulos);
                        // echo '</pre>';
                        ?>
                    </td>
                    <td>
                      <?php // Clase 475
                      $eventos_resultado = $registrado['talleres_registrados'];
                      $talleres = json_decode($eventos_resultado, true);
                      if(isset($talleres['eventos'])){
                        $talleres = implode("', '", $talleres['eventos']);
                      
                        $sql_talleres = "SELECT nombre_evento, fecha_evento, hora_evento FROM eventos WHERE clave IN ('$talleres') OR id_evento IN ('$talleres') ";
                        
                        $resultado_talleres = $conn->query($sql_talleres);

                        while ($eventos = $resultado_talleres->fetch_assoc()) {
                          echo $eventos['nombre_evento'] . " - " . $eventos['fecha_evento'] . " - " . $eventos['hora_evento'] . "<br>";
                        }
                      } else {
                        echo "No selecciono ningún taller";
                      }
                      /*
                      echo $sql_talleres;
                      echo '<pre>';
                        var_dump($eventos);
                      echo '</pre>';
                      */

                      ?>
                    </td>
                    <td><?php echo $registrado['nombre_regalo']; ?></td>
                    <td>$ <?php echo (float) $registrado['total_pagado']; ?></td>
                    <td>
                      <a href="editar-registro.php?id=<?php echo $registrado['id_registrado']; ?>" class="btn btn-info btn-xs margin">
                      <i class="fas fa-pencil-alt"></i>
                      </a>

                      <a href="#" data-id="<?php echo $registrado['id_registrado']; ?>" data-tipo="registrado" class="btn btn-danger btn-xs margin borrar_registro">
                      <i class="far fa-trash-alt"></i>
                      </a>
                    </td>
                  </tr>
                <?php } ?>

              </tbody>
              <tfoot>
                <tr>
                  <th>Nombre</th>
                  <th>Email</th>
                  <th>Fecha Registro</th>
                  <th>Artículos</th>
                  <th>Talleres</th>
                  <th>Regalo</th>
                  <th>Compra</th>
                  <th>Acciones</th>
                </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php
include_once 'templates/footer.php';
?>