<?php // Clase 486

include_once 'funciones/sesiones.php';
include_once 'funciones/funciones.php';

$sql = " SELECT fecha_registrado, COUNT(*) AS resultado FROM registrados GROUP BY DATE(fecha_registrado) ORDER BY fecha_registrado ";
$resultado = $conn->query($sql);

$arreglo_registros = array();
while($resgistro_dia = $resultado->fetch_assoc()) {

    $fecha = $resgistro_dia['fecha_registrado'];
    $registro['fecha'] = date('Y-m-d', strtotime($fecha));
    $registro['cantidad'] = $resgistro_dia['resultado'];

    $arreglo_registros[] = $registro;

    echo json_encode($arreglo_registros);
/*
    echo '<pre>';
    var_dump(json_encode($arreglo_registros));
    //var_dump($arreglo_registros);
    echo '</pre>';
    */
}


