$(document).ready(function () {
  $('#guardar-registro').on('submit', function (e) {
    e.preventDefault();

    var datos = $(this).serializeArray();

    $.ajax({ // Creamos el llamado Ajax
      type: $(this).attr('method'), // El tipo es del mismo que este en el formulario (este caso es POST)
      data: datos, // Los datos son lo que estan enviandose por el serializeArray()
      url: $(this).attr('action'), // Los datos los enviamos por medio del forumulario con el action
      dataType: 'json', // siempre tipo json
      success: function (data) { // Hacemos el llamado de los datos
        console.log(data);
        var resultado = data;
        if (resultado.respuesta == 'exito') {
          swal({
            type: 'success',
            title: '¡Correcto!',
            text: 'Se guardo correctamente.',
            showConfirmButton: true
          });
          // setTimeout(() => {
          //   window.location.href = 'lista-admin.php';
          // }, 2000);
        } else {
          swal({
            type: 'error',
            title: 'Oops...',
            text: 'Algo salio mal'
          })
        }
      }
    })
  });

  /* ============================================================================================= */

  // crear categoria NO ESTA LIGADA A NADA - probar resetear el formulario
  $('#nueva-categoria').on('submit', function (e) {
    e.preventDefault();

    var datos = $(this).serializeArray();

    $.ajax({ // Creamos el llamado Ajax
      type: $(this).attr('method'), // El tipo es del mismo que este en el formulario (este caso es POST)
      data: datos, // Los datos son lo que estan enviandose por el serializeArray()
      url: $(this).attr('action'), // Los datos los enviamos por medio del forumulario con el action
      dataType: 'json', // siempre tipo json
      success: function (data) { // Hacemos el llamado de los datos
        console.log(data);
        var resultado = data;
        console.log(resultado.respuesta);
        if (resultado.respuesta == 'exito') {
          swal.fire({
            type: 'success',
            title: '¡Correcto!',
            text: 'Se guardo correctamente.',
            showConfirmButton: true
          });
          // setTimeout(() => {
          //   window.location.href = 'lista-admin.php';
          // }, 2000);
        } else {
          swal.fire({
            type: 'error',
            title: 'Oops...',
            text: 'Algo salio mal'
          })
        }
      }
    })
  });

  /* ============================================================================================= */

  // Clase 468
  // Se ejecuta cuando hay un archivo
  $('#guardar-registro-archivo').on('submit', function (e) {
    e.preventDefault();

    var datos = new FormData(this);

    $.ajax({ // Creamos el llamado Ajax
      type: $(this).attr('method'), // El tipo es del mismo que este en el formulario (este caso es POST)
      data: datos, // Los datos son lo que estan enviandose por el FormData(this)
      url: $(this).attr('action'), // Los datos los enviamos por medio del forumulario con el action
      dataType: 'json', // siempre tipo json
      contentType: false, // estos SIEMPRE VAN cuando se manda un archivo por AJAX
      processData: false,
      async: true,
      cache: false,
      success: function (data) { // Hacemos el llamado de los datos
        // console.log(data);
        var resultado = data;
        // console.log(resultado.respuesta);
        if (resultado.respuesta == 'exito') {
          swal({
            type: 'success',
            title: '¡Correcto!',
            text: 'Se guardo correctamente.',
            showConfirmButton: true
          });
          // setTimeout(() => {
          //   window.location.href = 'lista-admin.php';
          // }, 2000);
        } else {
          swal({
            type: 'error',
            title: 'Oops...',
            text: 'Algo salio mal'
          })
        }
      }
    })
  });

    /* ============================================================================================= */

  // Clase 449: Eliminar un registro
  $('.borrar_registro').on('click', function (e) {
    e.preventDefault();

    var id = $(this).attr('data-id');
    var tipo = $(this).attr('data-tipo');

    swal.fire({
      title: '¿Estás seguro?',
      text: "Un registro eliminado no se puede recuperar",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, eliminalo!',
      cancelButtonText: 'Cancelar'
    }).then(function (resultado) {
      if (resultado.value) {
        $.ajax({
          type: 'post',
          data: {
            'id': id,
            'registro': 'eliminar'
          },
          url: 'modelo-' + tipo + '.php',
          success: function (data) {
            console.log(data);
            var resultado = JSON.parse(data);
            if (resultado.respuesta == 'exito') {
              swal.fire(
                '¡Eliminado!',
                'El registro ha sido eliminado.',
                'success'
              )
              jQuery('[data-id="' + resultado.id_eliminado + '"]').parents('tr').remove();
            }
          }
        }); //$.ajax
      } else {
        Swal.fire({
          type: 'info',
          title: 'Acción cancelada'
        })
      }
    }) // .then
  })
})
