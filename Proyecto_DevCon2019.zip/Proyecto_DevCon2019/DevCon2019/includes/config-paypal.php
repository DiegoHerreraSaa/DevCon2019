<?php
// Clase 412
require 'paypal/autoload.php';

define('URL_SITIO', 'http://localhost/Proyecto-Web');

$apiContext = new \PayPal\Rest\ApiContext(
    new \PayPal\Auth\OAuthTokenCredential(
        // Aqui va el ClienteID de la página de paypal
        'AZcVnBoQLiIDtHzlgqqtP0QYadL8zdU1kkzeIvV_bWV-p88F8NbXNSyiDqwk5IIOjXjnAOP_TtqnsGkx',
        // y despues el Secret
        'EMiuJCZ6u1_lALR45ErPRof-Aj2BRs0ZiSs_Zswdl1UPuYwpavaMJirF3ENMltSRXVZNP4SNFbtxLOSK'
    )
);