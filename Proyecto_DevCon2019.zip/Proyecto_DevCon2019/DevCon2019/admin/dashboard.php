<?php

include_once 'funciones/sesiones.php';
include_once 'funciones/funciones.php';
include_once 'templates/header.php';
include_once 'templates/barra.php';
include_once 'templates/navegacion.php';

?>



<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header /Page header/ -->
    <section class="content-header">
        <h1>
            Dashboard
            <small>Información sobre el evento</small>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Clase 486 -->
        <div class="row"> 
        <div class="box-body chart-responsive">
              <div class="chart" id="grafica-registros" style="height: 300px;"></div>
            </div>
            <!-- /.box-body -->
        </div>
        
        <!-- ============================================================================================== -->

        <h2 class="page-header">Resumen de registros</h2>
        <div class="row">
            <!-- Clase 484 -->
            <!-- Small boxes /Stat box/ -->
            <!-- Usuarios REGISTRADOS -->
            <div class="col-lg-3 col-xs-6">
                <?php
                // Realizo consulta en bd para traer cantidad de usuarios registrados
                $sql = "SELECT COUNT(id_registrado) AS total_registros FROM registrados ";
                $resultado = $conn->query($sql);
                $total_registrados = $resultado->fetch_assoc();
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $total_registrados['total_registros']; ?></h3>

                        <p>Total registrados</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <a href="lista-registrados.php" class="small-box-footer">
                        Más información <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>

            <!-- Usuarios PAGADOS -->
            <div class="col-lg-3 col-xs-6">
                <?php
                $sql = "SELECT COUNT(id_registrado) AS total_registros FROM registrados WHERE pagado = 1 ";
                $resultado = $conn->query($sql);
                $total_registrados = $resultado->fetch_assoc();
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $total_registrados['total_registros']; ?></h3>

                        <p>Total pagados</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <a href="lista-registrados.php" class="small-box-footer">
                        Más información <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>

            <!-- Usuarios NO PAGADOS -->
            <div class="col-lg-3 col-xs-6">
                <?php
                $sql = "SELECT COUNT(id_registrado) AS total_registros FROM registrados WHERE pagado = 0 ";
                $resultado = $conn->query($sql);
                $total_registrados = $resultado->fetch_assoc();
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $total_registrados['total_registros']; ?></h3>

                        <p>Total sin pagar</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-user-times"></i>
                    </div>
                    <a href="lista-registrados.php" class="small-box-footer">
                        Más información <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>

            <!-- Total recaudo pagado -->
            <div class="col-lg-3 col-xs-6">
                <?php
                $sql = "SELECT SUM(total_pagado) AS ganancias FROM registrados WHERE pagado = 1 ";
                $resultado = $conn->query($sql);
                $total_ganancias = $resultado->fetch_assoc();
                ?>
                <!-- small box -->
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>$ <?php echo $total_ganancias['ganancias']; ?></h3>

                        <p>Ganancias totales</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <a href="lista-registrados.php" class="small-box-footer">
                        Más información <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- ============================================================================================== -->

        <h2 class="page-header">Regalos</h2>

        <div class="row">

            <!-- Total pulseras -->
            <div class="col-md-3 col-sm-6 col-xs-12"> 
                <?php
                $sql = "SELECT COUNT(total_pagado) AS pulseras FROM registrados WHERE pagado = 1 AND regalo = 1  ";
                $resultado = $conn->query($sql);
                $regalo = $resultado->fetch_assoc();
                ?>
                <div class="info-box">
                    <span class="info-box-icon bg-maroon"><i class="fas fa-gifts"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Pulseras</span>
                        <span class="info-box-number"><?php echo $regalo['pulseras']; ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>

            <!-- Total etiquetas -->
            <div class="col-md-3 col-sm-6 col-xs-12"> 
                <?php
                $sql = "SELECT COUNT(total_pagado) AS etiquetas FROM registrados WHERE pagado = 1 AND regalo = 2  ";
                $resultado = $conn->query($sql);
                $regalo = $resultado->fetch_assoc();
                ?>
                <div class="info-box">
                    <span class="info-box-icon bg-purple"><i class="fas fa-gifts"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Etiquetas</span>
                        <span class="info-box-number"><?php echo $regalo['etiquetas']; ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>

            <!-- Total plumas -->
            <div class="col-md-3 col-sm-6 col-xs-12"> 
                <?php
                $sql = "SELECT COUNT(total_pagado) AS plumas FROM registrados WHERE pagado = 1 AND regalo = 3  ";
                $resultado = $conn->query($sql);
                $regalo = $resultado->fetch_assoc();
                ?>
                <div class="info-box">
                    <span class="info-box-icon bg-navy-active"><i class="fas fa-gifts"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Plumas</span>
                        <span class="info-box-number"><?php echo $regalo['plumas']; ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
        </div>

        <!-- ============================================================================================== -->


    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php
include_once 'templates/footer.php';
?>