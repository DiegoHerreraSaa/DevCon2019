$(document).ready(function () {

  // Clase 438
  $('#login-admin').on('submit', function (e) {
    e.preventDefault();

    var datos = $(this).serializeArray();

    $.ajax({
      type: $(this).attr('method'),
      data: datos,
      url: $(this).attr('action'),
      dataType: 'json',
      success: function (data) {
        // console.log(data); // este es que imprime la información del prepare del archivo insertar-admin en las lineas 56 al 85
        var resultado = data;
        if (resultado.respuesta == 'exito') {
          swal({
            title: '¡Login Correcto!',
            text: 'Bienvenid@ ' + resultado.usuario + ' !!',
            type: 'success',
            showConfirmButton: false
          })
          setTimeout(() => {
            window.location.href = 'admin-area.php';
          }, 2000);
        } else {
          swal({
            type: 'error',
            title: 'Oops...',
            text: 'Usuario o password incorrectos',
          })
        }

      }
    })
  })
})
