<?php include_once'includes/templates/header.php' ?>

<section class="seccion contenedor">
    <h2>La mejor conferencia de diseño web en español</h2>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae harum, natus eaque iusto officiis ea, alias molestiae esse modi. Reprehenderit, voluptatibus omnis asperiores provident? Dolor distinctio ducimus recusandae, quisquam iure! Lorem ipsum dolor sit amet, consectetur adipisicing elit.
    </p>
</section>
<!--.seccion-->

<!-- GALERIA DE FOTOS -->
<section class="seccion contenedor">
    <h2>Galería de fotos</h2>

    <div class="galeria">
        <a href="img/galeria/01.jpg" data-lightbox="galeria">
            <!-- el data-lightbox es el atributo que hace que se active el plugin de jquery de las imagenes -->
            <img src="img/galeria/thumbs/01.jpg"> <!-- thumbs significa que la foto es miniatura -->
        </a>

        <a href="img/galeria/02.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/02.jpg">
        </a>

        <a href="img/galeria/03.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/03.jpg">
        </a>

        <a href="img/galeria/04.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/04.jpg">
        </a>

        <a href="img/galeria/05.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/05.jpg">
        </a>

        <a href="img/galeria/06.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/06.jpg">
        </a>

        <a href="img/galeria/07.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/07.jpg">
        </a>

        <a href="img/galeria/08.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/08.jpg">
        </a>

        <a href="img/galeria/09.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/09.jpg">
        </a>

        <a href="img/galeria/10.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/10.jpg">
        </a>

        <a href="img/galeria/11.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/11.jpg">
        </a>

        <a href="img/galeria/12.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/12.jpg">
        </a>

        <a href="img/galeria/13.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/13.jpg">
        </a>

        <a href="img/galeria/14.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/14.jpg">
        </a>

        <a href="img/galeria/15.jpg" data-lightbox="galeria">
            <img src="img/galeria/thumbs/15.jpg">
        </a>


    </div>
</section> <!-- .galeria-fotos -->


<?php include_once'includes/templates/footer.php' ?>