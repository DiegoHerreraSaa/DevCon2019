<?php include_once 'includes/templates/header.php'; ?>



<!-- INVITADOS-->

<!--<section class="seccion contenedor">
    <h2>Invitados</h2>-->


    <?php include_once 'includes/templates/invitados.php' ?>


<?php include_once 'includes/templates/footer.php' ?> 