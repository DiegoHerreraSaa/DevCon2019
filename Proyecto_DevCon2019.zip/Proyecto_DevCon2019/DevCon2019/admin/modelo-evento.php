<?php // Clase 455
    include_once 'funciones/funciones.php';

    if(isset($_POST['titulo_evento'])){
        $titulo = $_POST['titulo_evento'];
        $categoria_id = $_POST['categoria_evento'];
        $invitado_id = $_POST['invitado'];
        // obtener fecha formateada
        $fecha = $_POST['fecha_evento'];
        $fecha_formateada = date('Y-m-d', strtotime($fecha));
        $hora = $_POST['hora_evento'];
        // obtener hora formateada
        $hora_formateada = date('H:i', strtotime($hora));

        if($categoria_id == 1){
            $clave = 'sem_extra';
        } else if($categoria_id == 2){
            $clave = 'conf_extra';
        } else {
            $clave = 'taller_extra';
        }
    }

if ($_POST["registro"] == 'nuevo') {
    // die(json_encode($_POST));

    try {
    $stmt = $conn->prepare(" INSERT INTO eventos (nombre_evento, fecha_evento, hora_evento, id_categoria, id_invitado, clave) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('sssiis', $titulo, $fecha_formateada, $hora_formateada, $categoria_id, $invitado_id, $clave);
    $stmt->execute();
    $id_insertado = $stmt->insert_id;
    if($stmt->affected_rows){
        $respuesta = array(
            'respuesta' => 'exito',
            'id_insertado' => $id_insertado
        );
    } else {
        $respuesta = array(
            'respuesta' => 'error'
        );
    }
    $stmt->close();
    $conn->close();
    } catch (Exception $e) {
        $respuesta = array(
            'respuesta' => $e->getMessage()
        );
    }
    die(json_encode($respuesta));
}

/* ================================================================================================================== */

if ($_POST['registro'] == 'actualizar') {
    $id_registro = $_POST['id_registro'];

    // die(json_encode($_POST));

    try { 
        $stmt = $conn->prepare("UPDATE eventos SET nombre_evento = ?, fecha_evento = ?, hora_evento = ?, id_categoria = ?, id_invitado = ?, clave = ?, editado = NOW() WHERE id_evento = ? ");
        $stmt->bind_param("sssiisi", $titulo, $fecha_formateada, $hora_formateada, $categoria_id, $invitado_id, $clave, $id_registro );
        $stmt->execute();
        if($stmt->affected_rows > 0){
            $respuesta = array(
                'respuesta' => 'exito',
                'id_actualizado' => $id_registro
            );
        } else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        $respuesta = array(
            'respuesta' => $e->getMessage()
        );
    }
    die(json_encode($respuesta));
}

/* ================================================================================================================== */

if ($_POST['registro'] == 'eliminar') {
    $id_borrar = $_POST['id'];

    try {
        $stmt = $conn->prepare("DELETE FROM eventos WHERE id_evento = ?");
        $stmt->bind_param('i', $id_borrar);
        $stmt->execute();
        if($stmt->affected_rows) {
            $respuesta = array(
                'respuesta' => 'exito',
                'id_eliminado' => $id_borrar
            );
        } else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
    } catch (Exception $e) {
        $respuesta = array(
            'respuesta' => $e->getMessage()
        );
    }
    die(json_encode($respuesta));
}


