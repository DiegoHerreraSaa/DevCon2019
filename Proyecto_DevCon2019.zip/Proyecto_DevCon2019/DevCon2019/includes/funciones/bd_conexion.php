<?php

// clase 354

$conn = new mysqli('localhost', 'root', '', 'webmastercol2019');

if ($conn->connect_error) {
    echo $error->$conn->connect_error;
}