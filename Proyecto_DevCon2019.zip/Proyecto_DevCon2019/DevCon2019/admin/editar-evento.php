<?php // Clase 456

$id = $_GET['id'];

if (!filter_var($id, FILTER_VALIDATE_INT)) :
    die('Error');
else :

    include_once 'funciones/sesiones.php';
    include_once 'funciones/funciones.php';
    include_once 'templates/header.php';
    include_once 'templates/barra.php';
    include_once 'templates/navegacion.php';

    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Edición de Eventos
                <small>Edita los campos necesarios.</small>
            </h1>
        </section>

        <div class="row">
            <div class="col-md-8">
                <!-- Main content -->
                <section class="content">

                    <!-- Default box -->
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">Editar Evento</h3>
                        </div>
                        <div class="box-body">

                            <?php
                                $sql = "SELECT * FROM eventos WHERE id_evento = $id ";
                                $resultado = $conn->query($sql);
                                $evento = $resultado->fetch_assoc();
                                // echo '<pre>';
                                //     var_dump($evento);
                                // echo '</pre>';
                            ?>

                            <!-- form start -->
                            <form role="form" name="guardar-registro" id="guardar-registro" method="post" action="modelo-evento.php">
                                <div class="box-body">
                                    <div class="form-group">
                                        <label for="usuario">Título Evento:</label>
                                        <input type="text" class="form-control" id="titulo_evento" name="titulo_evento" placeholder="Ingrese el título del evento" value="<?php echo $evento['nombre_evento']; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="nombre">Categoría:</label>
                                        <select name="categoria_evento" class="form-control select2" id="">
                                            <option value="0">- Seleccione -</option>
                                            <?php
                                            try {
                                                $categoria_actual = $evento['id_categoria'];
                                                $sql = "SELECT * FROM categoria_evento ";
                                                $resultado = $conn->query($sql);
                                                while ($cat_evento = $resultado->fetch_assoc()) {
                                                    if($cat_evento['id_categoria'] == $categoria_actual) { ?>
                                                    <option value="<?php echo $cat_evento['id_categoria']; ?>" selected>
                                                        <?php echo $cat_evento['cat_evento']; ?>
                                                    </option>
                                                <?php } else { ?>
                                                    <option value="<?php echo $cat_evento['id_categoria']; ?>" >
                                                        <?php echo $cat_evento['cat_evento']; ?>
                                                    </option>
                                                <?php }
                                                }
                                        } catch (Exception $e) {
                                            echo 'Error: ' . $e->getMessage();
                                        }

                                        ?>
                                        </select>
                                    </div>

                                    <!-- Date -->
                                    <div class="form-group">
                                        <label>Fecha:</label>
                                        <?php
                                            $fecha = $evento['fecha_evento'];
                                            $formato_fecha = date('m/d/Y', strtotime($fecha));
                                        ?>
                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="far fa-calendar-alt"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right" id="datepicker" name="fecha_evento" value="<?php echo $formato_fecha; ?>">
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                    <!-- /.form group -->

                                    <!-- time Picker -->
                                    <div class="bootstrap-timepicker">
                                        <div class="form-group">
                                            <label>Hora:</label>
                                            <?php
                                                $hora = $evento['hora_evento'];
                                                $hora_formato = date('H:i a', strtotime($hora)); 
                                            ?>
                                            <div class="input-group">
                                                <input type="text" class="form-control timepicker" name="hora_evento" value="<?php echo $hora_formato; ?>">

                                                <div class="input-group-addon">
                                                    <i class="far fa-clock"></i>
                                                </div>
                                            </div>
                                            <!-- /.input group -->
                                        </div>
                                        <!-- /.form group -->
                                    </div>

                                    <div class="form-group">
                                        <label for="nombre">Invitado:</label>
                                        <select name="invitado" class="form-control select2">
                                            <option value="0">- Seleccione -</option>
                                            <?php
                                            try {
                                                $invitado_actual = $evento['id_invitado'];
                                                $sql = "SELECT id_invitado, nombre_invitado, apellido_invitado FROM invitados ";
                                                $resultado = $conn->query($sql);
                                                while ($invitados = $resultado->fetch_assoc()) {
                                                    if($invitados['id_invitado'] == $invitado_actual) { ?>
                                                        <option value="<?php echo $invitados['id_invitado']; ?>" selected>
                                                            <?php echo $invitados['nombre_invitado'] . " " . $invitados['apellido_invitado']; ?>
                                                        </option>
                                                    <?php } else { ?>
                                                        <option value="<?php echo $invitados['id_invitado']; ?>">
                                                            <?php echo $invitados['nombre_invitado'] . " " . $invitados['apellido_invitado']; ?>
                                                        </option>
                                                    <?php } // fin if
                                                } // fin while
                                        } catch (Exception $e) {
                                            echo 'Error: ' . $e->getMessage();
                                        }

                                        ?>
                                        </select>
                                    </div>
                                    <!-- /.box-body -->

                                    <div class="box-footer">
                                        <input type="hidden" name="registro" value="actualizar">
                                        <input type="hidden" name="id_registro" value="<?php echo $id; ?>">
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </form>
                            <!-- /.form -->
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->

                </section>
                <!-- /.content -->
            </div>
            <!-- /.col-md-8 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.content-wrapper -->

    <?php
    include_once 'templates/footer.php';
endif;
?>