<?php include_once'includes/templates/header.php' ?>



<!-- CALENDARIO DE EVENTOS -->
<section class="seccion contenedor">
    <h2>Calendario de Eventos</h2>

    <?php
    try { // clase 355
        require_once('includes/funciones/bd_conexion.php'); // clase 357
        $sql = " SELECT id_evento, nombre_evento, fecha_evento, hora_evento, cat_evento, icono, nombre_invitado, apellido_invitado ";
        $sql .= " FROM eventos ";
        $sql .= " INNER JOIN categoria_evento ";
        $sql .= " ON eventos.id_categoria = categoria_evento.id_categoria ";
        $sql .= " INNER JOIN invitados ";
        $sql .= " ON eventos.id_invitado = invitados.id_invitado ";
        $sql .= " ORDER BY fecha_evento ";
        $resultados = $conn->query($sql);
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
    ?>

    <div class="calendario">
        <?php
        $calendario = array();
        while ($eventos = $resultados->fetch_assoc()) { // clase 356
            // Obteniendo las fechas de los eventos - clase 358
            $fecha = $eventos['fecha_evento'];

            $evento = array(
                'Título: ' => $eventos['nombre_evento'],
                'Fecha: ' => $eventos['fecha_evento'],
                'Hora: ' => $eventos['hora_evento'],
                'Categoría: ' => $eventos['cat_evento'],
                'icono' => $eventos['icono'],
                'Invitado: ' => $eventos['nombre_invitado'] . " " . $eventos['apellido_invitado']
            );

            $calendario[$fecha][] = $evento;
        } // fin while fetch_assoc
        // imprimiendo todos los arreglos - clase 359


        foreach ($calendario as $dia => $lista_eventos) {

                echo "<h3>";
                    echo '<i class="far fa-calendar-alt"></i> ';
                    setlocale(LC_TIME, 'spanish');
                    echo ucfirst(utf8_encode(strftime("%A, %d de %B del %Y", strtotime($dia))));
                echo "</h3>";

            foreach ($lista_eventos as $evento) {

                echo '<div class="dia">';

                echo '<p class="titulo">';
                echo $evento['Título: '];
                echo '</p>';

                echo '<p class="hora"> <i class="far fa-clock" aria-hidden="true"></i> ';
                echo $evento['Fecha: '] . " " . $evento['Hora: '];
                echo '</p>';

                echo '<p class="categoria"> <i class=" ';
                echo $evento['icono'];
                echo '" aria-hidden="true"></i> ';
                echo $evento['Categoría: '];
                echo '</p>';

                echo '<p class="invitado"> <i class="fas fa-user"></i> ';
                echo $evento['Invitado: '];
                echo '</p>';



                echo '</div>';
            } // fin foreach eventos clase 360
        } // fin foreach de dias





        $conn->close();
        ?>

    </div> <!-- .calendario-->

</section> <!-- .calendario-eventos -->


<?php include_once'includes/templates/footer.php' ?>