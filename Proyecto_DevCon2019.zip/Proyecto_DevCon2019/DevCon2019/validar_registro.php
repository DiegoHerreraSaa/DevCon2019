<!-- ES MUY RECOMENDABLE SIEMPRE HACER ESTAS VALIDACIONES -->
<?php if (isset($_POST['submit'])) :
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $regalo = $_POST['regalo'];
        $total = $_POST['total_pedido'];
        $fecha = date('Y-m-d H:i:s');

        // PEDIDOS JSON clase 343 pasar estas variables como una funcion JSON
        $boletos = $_POST['boletos'];
        $camisas = $_POST['pedido_camisas'];
        $etiquetas = $_POST['pedido_etiquetas'];
        include_once 'includes/funciones/funciones.php';
        $pedido = productos_json($boletos, $camisas, $etiquetas);
        // EVENTOS JSON clase 345
        $eventos = $_POST['registro'];
        $registro = eventos_json($eventos);
        try { //clase 346 
            require_once('includes/funciones/bd_conexion.php');
            $stmt = $conn->prepare("INSERT INTO registrados (nombre_registrado, apellido_registrado, email_registrado, fecha_registrado, pases_articulos, talleres_registrados, regalo, total_pagado) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->bind_param("ssssssis", $nombre, $apellido, $email, $fecha, $pedido, $registro, $regalo, $total); 
            // la s significa cadenas en ingles (string) y el i en integer, deben ser en el orden del prepare
            $stmt->execute();
            $stmt->close();
            $conn->close();
            header('Location: validar_registro.php?exitoso=1');
        } catch (Exception $ex) {
            $error =  $ex->getMessage();
        }
        ?>
    <?php endif ?>
<?php include_once 'includes/templates/header.php' ?>

<section class="seccion contenedor">
    <h2>Resumen de registro</h2>

    <?php
        if(isset($_GET['exitoso'])):
            if($_GET['exitoso'] == "1"):
                echo '<h3 class="regExitoso">Tu registro al evento ha sido exitoso. <span><br>¡ Te esperamos !</span></h3>';
            endif;
        endif;
    ?>

</section>

<?php include_once 'includes/templates/footer.php' ?> 