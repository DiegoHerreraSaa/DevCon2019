<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 2.4.0
  </div>
  <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
  reserved.
</footer>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="js/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>
<!-- bootstrap datepicker -->
<script src="js/bootstrap-datepicker.min.js"></script>
<!-- Select2 -->
<script src="js/select2.full.min.js"></script>
<!-- bootstrap time picker -->
<script src="js/bootstrap-timepicker.min.js"></script>
<!-- FontAwesome Icon Picker -->
<script src="js/fontawesome-iconpicker.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="js/demo.js"></script>
<!-- sweetAlert2 -->
<script src="js/sweetalert2.all.min.js"></script>
<!-- notificaciones ajax -->
<script src="js/admin-ajax.js"></script>
<!-- DataTables -->
<script src="js/jquery.dataTables.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="js/icheck.min.js"></script>
<!-- DataTables Bootstrap -->
<script src="js/dataTables.bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="js/morris/raphael.min.js"></script>
<script src="js/morris/morris.min.js"></script>
<!-- login -->
<script src="js/login-ajax.js"></script>
<!-- cotizador -->
<script src="../js/cotizador.js"></script>
<!-- llamados a funciones de los mins -->
<script src="js/app.js"></script>

</body>

</html>