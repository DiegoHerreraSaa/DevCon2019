// Formato tablas clase 444

$(document).ready(function () {
  $('.sidebar-menu').tree()

  // DataTables
  $('#registros').DataTable({
    'paging': true,
    'lengthChange': false,
    'searching': true,
    'ordering': true,
    'info': true,
    'autoWidth': false,
    "language": {
      "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json" // https://datatables.net/examples/index
    }
  });

  $('#crear-registro-admin').attr('disabled', true);

  $('#repetir_password').on('blur', function () {
    var password_nuevo = $('#password').val();

    if ($(this).val() == password_nuevo) {
      $('#resultado_password').text('Correcto!');
      $('#resultado_password').parents('.form-group').addClass('has-success').removeClass('has-error');
      $('input#password').parents('.form-group').addClass('has-success').removeClass('has-error');
      $('#crear-registro-admin').attr('disabled', false);
      $('#editar-registro').attr('disabled', false);
    } else {
      $('#resultado_password').text('No son iguales!');
      $('#resultado_password').parents('.form-group').addClass('has-error');
      $('input#password').parents('.form-group').addClass('has-error');
      $('#crear-registro-admin').attr('disabled', true);
      $('#editar-registro').attr('disabled', true);
    }
  });

  //Date picker
  $('#datepicker').datepicker({
    autoclose: true
  });

  //Initialize Select2 Elements
  $('.select2').select2();

  //Timepicker
  $('.timepicker').timepicker({
    showInputs: false
  });

  //IconPicker FontAwesome
  $('#icono').iconpicker();

  //iCheck for checkbox and radio inputs
  $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
    checkboxClass: 'icheckbox_minimal-blue',
    radioClass   : 'iradio_minimal-blue'
  });

  $.getJSON('servicio-registrados.php', function(data) {
    // console.log(data);
    // MORRIS LINE CHART Clase 486
  var line = new Morris.Line({
    element: 'grafica-registros',
    resize: true,
    data: data,
    xkey: 'fecha',
    ykeys: ['cantidad'],
    labels: ['Q registros'],
    lineColors: ['#3c8dbc'],
    hideHover: 'auto'
  });
  });

  

})
