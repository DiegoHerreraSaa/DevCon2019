<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DevCon Col 2019</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--<link rel="manifest" href="site.webmanifest"> -->
    <link rel="apple-touch-icon" href="icon.png">
    <!-- Place favicon.ico in the root directory -->

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Oswald|PT+Sans" rel="stylesheet">


    <?php

    $archivo = basename($_SERVER['PHP_SELF']);
    $pagina = str_replace(".php", "", $archivo);
    if ($pagina == 'invitados') {
        echo '<link rel="stylesheet" href="css/colorboxElement.css">';
        echo '<link rel="stylesheet" href="css/colorbox.css">';
    } elseif ($pagina == 'conferencia') {
        echo '<link rel="stylesheet" href="css/lightbox.css">';
    } elseif ($pagina == 'index') {
        echo '<link rel="stylesheet" href="css/colorboxElement.css">';
        echo '<link rel="stylesheet" href="css/colorbox.css">';
        echo '<link rel="stylesheet" href="https://unpkg.com/leaflet@1.4.0/dist/leaflet.css"
        integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA=="
        crossorigin=""/>';
    }
    ?>

    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.2"></script>

    <link rel="stylesheet" href="css/calendario.css">
    <link rel="stylesheet" href="css/main.css">
    <script src="js/vendor/modernizr-3.6.0.min.js"></script>
</head>

<body class="<?php echo $pagina; ?>">
    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
      <![endif]-->

    <!-- Add your site or application content here -->



    <header class="site-header">
        <div class="hero">
            <div class="contenido-header">
                <nav class="redes-sociales">
                    <a href="https://www.facebook.com/indracompany/" target="_blank"><i class="fab fa-facebook-square" aria-hidden="true"></i></a>
                    <a href="https://twitter.com/IndraCompany?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" target="_blank"><i class="fab fa-twitter-square" aria-hidden="true"></i></a>
                    <a href="https://www.youtube.com/user/theindracompany" target="_blank"><i class="fab fa-youtube-square" aria-hidden="true"></i></a>
                    <a href="https://www.instagram.com/indracompany/?hl=es-la" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                </nav>
                <div class="informacion-evento">
                    <div class="clearfix">
                        <p class="fecha">
                            <i class="far fa-calendar-alt"></i> 19-21 Jul 2019
                        </p>
                        <p class="ciudad">
                            <i class="fas fa-map-marker-alt"></i> Cali, Colombia
                        </p>
                    </div>

                    <h1 class="nombre-sitio">devcon colombia</h1>
                    <p class="slogan">
                        Convención Internacional de <span> desarrollo y programación</span> Colombia 2019
                    </p>
                </div>
                <!--.informacion-evento-->

            </div>
        </div>
        <!--.hero-->
    </header>



    <div class="barra">
        <div class="contenedor clearfix">
            <div class="logo">
                <a href="index.php">
                    <img src="img/logoWebMtr.png" alt="logo Web-Master">
                </a>
            </div>

            <div class="menu-movil">
                <span></span>
                <span></span>
                <span></span>
            </div>

            <nav class="navegacion-principal clearfix">
                <a href="index.php">Inicio</a>
                <a href="conferencia.php">Conferencia</a>
                <a href="calendario.php">Calendario</a>
                <a href="invitados.php">Invitados</a>
                <a href="registro.php">Reservaciones</a>
            </nav>
        </div>
        <!--.contenedor-->
    </div>
    <!--.barra-->