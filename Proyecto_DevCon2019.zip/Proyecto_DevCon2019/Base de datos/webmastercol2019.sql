-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 01-07-2019 a las 05:00:08
-- Versión del servidor: 5.7.24
-- Versión de PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `webmastercol2019`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `password` varchar(60) NOT NULL,
  `editado` datetime DEFAULT NULL,
  `nivel` int(1) DEFAULT NULL,
  PRIMARY KEY (`id_admin`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `admins`
--

INSERT INTO `admins` (`id_admin`, `usuario`, `nombre`, `password`, `editado`, `nivel`) VALUES
(1, 'administrador', 'Diego Herrera', '$2y$12$M6.ThEuCKLDXO2GRbEbl/ea1pzK2HRFxRllmdBEka/nYY6NOH7geC', '2019-04-23 10:07:04', 1),
(3, 'Usuario', 'Alexander Saa', '$2y$12$sYcA2d4AbSh2fBrpYDec2eSehpkYSShzb/kyo4tF/2sdq2D73jZOS', '2019-06-29 12:56:17', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria_evento`
--

DROP TABLE IF EXISTS `categoria_evento`;
CREATE TABLE IF NOT EXISTS `categoria_evento` (
  `id_categoria` tinyint(10) NOT NULL AUTO_INCREMENT,
  `cat_evento` varchar(50) NOT NULL,
  `icono` varchar(30) NOT NULL,
  `editado` datetime NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categoria_evento`
--

INSERT INTO `categoria_evento` (`id_categoria`, `cat_evento`, `icono`, `editado`) VALUES
(1, 'Seminario', 'fas fa-university', '0000-00-00 00:00:00'),
(2, 'Conferencias', 'fas fa-comments', '0000-00-00 00:00:00'),
(3, 'Talleres', 'fas fa-people-carry', '2019-04-25 09:54:59');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

DROP TABLE IF EXISTS `eventos`;
CREATE TABLE IF NOT EXISTS `eventos` (
  `id_evento` tinyint(10) NOT NULL AUTO_INCREMENT,
  `nombre_evento` varchar(100) NOT NULL,
  `fecha_evento` date NOT NULL,
  `hora_evento` time NOT NULL,
  `id_categoria` tinyint(10) NOT NULL,
  `id_invitado` tinyint(10) NOT NULL,
  `clave` varchar(10) NOT NULL,
  `editado` datetime NOT NULL,
  PRIMARY KEY (`id_evento`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_invitado` (`id_invitado`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`id_evento`, `nombre_evento`, `fecha_evento`, `hora_evento`, `id_categoria`, `id_invitado`, `clave`, `editado`) VALUES
(1, 'HTML5, CSS3 y JavaScript', '2019-07-20', '09:30:00', 3, 1, 'taller_01', '0000-00-00 00:00:00'),
(2, 'Flexbox', '2019-07-19', '12:00:00', 3, 3, 'taller_02', '0000-00-00 00:00:00'),
(3, 'Responsive Web Design', '2019-07-20', '14:00:00', 3, 2, 'taller_03', '0000-00-00 00:00:00'),
(4, 'Drupal', '2019-07-19', '17:00:00', 3, 4, 'taller_04', '0000-00-00 00:00:00'),
(5, 'WordPress', '2019-07-19', '19:00:00', 3, 5, 'taller_05', '0000-00-00 00:00:00'),
(6, 'Como ser freelancer', '2019-07-19', '17:30:00', 2, 5, 'conf_01', '0000-00-00 00:00:00'),
(7, 'Tecnologías del Futuro', '2019-07-19', '20:00:00', 2, 3, 'conf_02', '0000-00-00 00:00:00'),
(8, 'Seguridad en la Web', '2019-07-19', '19:00:00', 2, 2, 'conf_03', '0000-00-00 00:00:00'),
(9, 'Diseño UI y UX para móviles', '2019-07-19', '14:30:00', 1, 6, 'sem_01', '0000-00-00 00:00:00'),
(10, 'AngularJS', '2019-07-20', '10:00:00', 3, 1, 'taller_06', '0000-00-00 00:00:00'),
(11, 'PHP y MySQL', '2019-07-20', '12:00:00', 3, 2, 'taller_07', '0000-00-00 00:00:00'),
(12, 'JavaScript Avanzado', '2019-07-20', '14:00:00', 3, 3, 'taller_08', '0000-00-00 00:00:00'),
(13, 'SEO en Google', '2019-07-20', '17:00:00', 3, 4, 'taller_09', '0000-00-00 00:00:00'),
(14, 'De Photoshop a HTML5 y CSS3', '2019-07-20', '19:00:00', 3, 5, 'taller_10', '0000-00-00 00:00:00'),
(15, 'PHP Intermedio y Avanzado', '2019-07-20', '21:00:00', 3, 6, 'taller_11', '0000-00-00 00:00:00'),
(16, 'Como crear una tienda online que venda millones en pocos días', '2019-07-20', '10:00:00', 2, 6, 'conf_04', '0000-00-00 00:00:00'),
(17, 'Los mejores lugares para encontrar trabajo', '2019-07-20', '17:00:00', 2, 1, 'conf_05', '0000-00-00 00:00:00'),
(18, 'Pasos para crear un negocio rentable ', '2019-07-20', '19:00:00', 2, 2, 'conf_06', '0000-00-00 00:00:00'),
(19, 'Aprende a Programar en una mañana', '2019-07-20', '17:40:00', 1, 4, 'sem_02', '0000-00-00 00:00:00'),
(20, 'Diseño UI y UX para móviles', '2019-07-20', '17:00:00', 1, 5, 'sem_03', '0000-00-00 00:00:00'),
(21, 'Laravel', '2019-07-19', '10:00:00', 3, 1, 'taller_12', '0000-00-00 00:00:00'),
(22, 'Crea tu propia API', '2019-07-19', '12:00:00', 3, 2, 'taller_13', '0000-00-00 00:00:00'),
(23, 'JavaScript y jQuery', '2019-07-19', '14:00:00', 3, 3, 'taller_14', '0000-00-00 00:00:00'),
(24, 'Creando Plantillas para WordPress', '2019-07-19', '17:00:00', 3, 4, 'taller_15', '0000-00-00 00:00:00'),
(25, 'Tiendas Virtuales en Magento', '2019-07-19', '19:00:00', 3, 5, 'taller_16', '0000-00-00 00:00:00'),
(26, 'Como hacer Marketing en línea', '2019-07-21', '10:00:00', 2, 6, 'conf_07', '0000-00-00 00:00:00'),
(27, '¿Con que lenguaje debo empezar?', '2019-07-21', '17:00:00', 2, 2, 'conf_08', '0000-00-00 00:00:00'),
(28, 'Frameworks y librerias Open Source', '2019-07-21', '19:00:00', 2, 3, 'conf_09', '0000-00-00 00:00:00'),
(29, 'Creando una App en Android en una mañana', '2019-07-21', '10:00:00', 1, 4, 'sem_04', '0000-00-00 00:00:00'),
(30, 'Creando una App en iOS en una tarde', '2019-07-21', '17:00:00', 1, 1, 'sem_05', '0000-00-00 00:00:00'),
(31, 'NodeJS', '2019-07-21', '17:00:00', 1, 2, 'sem_extra', '0000-00-00 00:00:00'),
(32, 'Java Web Server', '2019-07-19', '19:15:00', 1, 1, 'sem_extra', '0000-00-00 00:00:00'),
(33, 'WordPress 2019', '2019-07-19', '10:30:00', 2, 5, 'conf_extra', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `invitados`
--

DROP TABLE IF EXISTS `invitados`;
CREATE TABLE IF NOT EXISTS `invitados` (
  `id_invitado` tinyint(10) NOT NULL AUTO_INCREMENT,
  `nombre_invitado` varchar(30) NOT NULL,
  `apellido_invitado` varchar(30) NOT NULL,
  `descripcion` text NOT NULL,
  `url_imagen` varchar(60) NOT NULL,
  PRIMARY KEY (`id_invitado`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `invitados`
--

INSERT INTO `invitados` (`id_invitado`, `nombre_invitado`, `apellido_invitado`, `descripcion`, `url_imagen`) VALUES
(1, 'Antonio', 'Gomez', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae harum, natus eaque iusto officiis ea, alias molestiae esse modi.', 'invitado7.jpg'),
(2, 'Valentina', 'Corredor', 'Reprehenderit, voluptatibus omnis asperiores provident? Dolor distinctio ducimus recusandae, quisquam iure!', 'invitado6.jpg'),
(3, 'Luciana', 'Zapata', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.Quae harum, natus eaque iusto officiis ea, alias molestiae esse modi.', 'invitado4.jpg'),
(4, 'Fernando', 'Herrera', 'Debitis qui amet at tempora, a dolore sapiente temporibus inventore ipsam, nemo quam minus voluptatum explicabo velit eum. ', 'invitado1.jpg'),
(5, 'Richard', 'Bustos', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae harum, natus eaque iusto officiis ea, alias molestiae esse modi.', 'invitado3.jpg'),
(6, 'Sandra', 'Torres', 'Quo aliquam architecto rerum sint pariatur veniam officia, eaque in assumenda alias facilis iure ratione, vero perferendis aperiam ipsam, ut numquam dicta.', 'invitado2.jpg'),
(7, 'Alexander', 'Gutierrez', 'Programador Web para Parque Soft', 'invitado9.jpg'),
(8, 'Daniela', 'Forero', 'Profesional en Mercadeo', 'invitado8.jpg'),
(9, 'Diego', 'Herrera Saa', 'Profesional en desarrollo de software para Indra Company', 'invitado5.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `regalos`
--

DROP TABLE IF EXISTS `regalos`;
CREATE TABLE IF NOT EXISTS `regalos` (
  `id_regalo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_regalo` varchar(50) NOT NULL,
  PRIMARY KEY (`id_regalo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `regalos`
--

INSERT INTO `regalos` (`id_regalo`, `nombre_regalo`) VALUES
(1, 'Pulsera'),
(2, 'Etiquetas'),
(3, 'Plumas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registrados`
--

DROP TABLE IF EXISTS `registrados`;
CREATE TABLE IF NOT EXISTS `registrados` (
  `id_registrado` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre_registrado` varchar(50) NOT NULL,
  `apellido_registrado` varchar(50) NOT NULL,
  `email_registrado` varchar(100) NOT NULL,
  `fecha_registrado` datetime NOT NULL,
  `pases_articulos` longtext NOT NULL,
  `talleres_registrados` longtext NOT NULL,
  `regalo` int(11) NOT NULL,
  `total_pagado` varchar(50) NOT NULL,
  `pagado` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_registrado`),
  KEY `regalo` (`regalo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `registrados`
--

INSERT INTO `registrados` (`id_registrado`, `nombre_registrado`, `apellido_registrado`, `email_registrado`, `fecha_registrado`, `pases_articulos`, `talleres_registrados`, `regalo`, `total_pagado`, `pagado`) VALUES
(1, 'Diego', 'Herrera', 'diegoh@gmail.com', '2019-04-28 22:17:54', '{\"un_dia\":{\"cantidad\":\"1\"},\"paseCompleto\":{\"cantidad\":\"\"},\"pase2Dias\":{\"cantidad\":\"\"},\"camisas\":3,\"etiquetas\":2}', '{\"eventos\":[\"9\",\"32\",\"21\",\"2\"]}', 3, '63.9', 1),
(2, 'Maria', 'Ruth', 'maria@yahoo.com', '2019-04-28 23:17:11', '{\"un_dia\":{\"cantidad\":\"\"},\"paseCompleto\":{\"cantidad\":\"1\"},\"pase2Dias\":{\"cantidad\":\"\"},\"camisas\":2,\"etiquetas\":3}', '{\"eventos\":[\"7\",\"24\",\"25\",\"18\",\"26\"]}', 1, '77.6', 1),
(3, 'Viviana', 'Torres', 'sandra@hotmail.com', '2019-04-28 23:32:51', '{\"un_dia\":{\"cantidad\":\"1\"},\"paseCompleto\":{\"cantidad\":\"1\"},\"pase2Dias\":{\"cantidad\":\"2\"},\"camisas\":2,\"etiquetas\":3}', '{\"eventos\":[\"9\",\"23\",\"19\",\"14\",\"31\",\"28\"]}', 1, '197.6', 1),
(4, 'Alexander', 'Saa', 'alex@gmail.com', '2019-04-28 23:41:56', '{\"un_dia\":{\"cantidad\":\"1\"},\"paseCompleto\":{\"cantidad\":\"\"},\"pase2Dias\":{\"cantidad\":\"0\"},\"camisas\":3,\"etiquetas\":4}', '{\"eventos\":[\"33\",\"2\",\"19\",\"17\"]}', 2, '69.9', 1),
(5, 'Diana', 'Gutierrea', 'diana@hotmail.com', '2019-04-28 23:48:26', '{\"un_dia\":{\"cantidad\":\"\"},\"paseCompleto\":{\"cantidad\":\"\"},\"pase2Dias\":{\"cantidad\":\"\"},\"camisas\":3,\"etiquetas\":1}', '[]', 1, '30.9', 1),
(6, 'Sofia', 'Medina', 'sofi@yahoo.com', '2019-04-28 23:53:16', '{\"un_dia\":{\"cantidad\":\"1\"},\"paseCompleto\":{\"cantidad\":\"\"},\"pase2Dias\":{\"cantidad\":\"\"}}', '{\"eventos\":[\"33\",\"22\"]}', 2, '30', 0);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD CONSTRAINT `eventos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria_evento` (`id_categoria`),
  ADD CONSTRAINT `eventos_ibfk_2` FOREIGN KEY (`id_invitado`) REFERENCES `invitados` (`id_invitado`);

--
-- Filtros para la tabla `registrados`
--
ALTER TABLE `registrados`
  ADD CONSTRAINT `registrados_ibfk_1` FOREIGN KEY (`regalo`) REFERENCES `regalos` (`id_regalo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
