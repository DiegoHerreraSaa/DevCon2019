    // MAPA: leaflet
if(document.getElementById('mapid')){


        var map = L.map('mapid').setView([3.379275, -76.528594], 16); // el 16 es el zoom, entre mas alto, mas zoom hace

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        L.marker([3.379275, -76.528594]).addTo(map)
                .bindPopup('DevCon Colombia  2019')
                .openPopup()
                .bindTooltip('Esto es un Tooltip')
                .openTooltip();
    }

$(function () {

    /* ****************** LETTERING, animación de las letras del título ****************** */

    $('.nombre-sitio').lettering();

    /* ==================== AGREGAR CLASE A MENU ================= */

    $('body.index .navegacion-principal a:contains("Inicio")').addClass('activo');
    $('body.conferencia .navegacion-principal a:contains("Conferencia")').addClass('activo');
    $('body.calendario .navegacion-principal a:contains("Calendario")').addClass('activo');
    $('body.invitados .navegacion-principal a:contains("Invitados")').addClass('activo');
    $('body.registro .navegacion-principal a:contains("Reservaciones")').addClass('activo');

    /* ****************** MENU FIJO ****************** */

    var windowHeight = $(window).height();
    var barraAltura = $('.barra').innerHeight();

    $(window).scroll(function () {
        var scroll = $(window).scrollTop();
        if (scroll > windowHeight) {
            $('.barra').addClass('fixed');
            $('body').css({'margin-top': barraAltura + 'px'});
        } else {
            $('.barra').removeClass('fixed');
            $('body').css({'margin-top': '0px'});
        }
    });

    /* ****************** MENU RESPONSIVO, ESTILO HAMBURGUESA ****************** */

    $('.menu-movil').on('click', function () {
        $('.navegacion-principal').slideToggle();
    })





    /* ****************** PROGRAMA DE CONFERENCIAS ****************** */

    /*$('div.ocultar').hide();*/ /*este codigo lo hice en css*/

    $('.programa-evento .info-curso:first').show();
    $('.menu-programa a:first').addClass('activo');

    $('.menu-programa a').on('click', function () {
        $('.menu-programa a').removeClass('activo');
        $(this).addClass('activo');
        $('.ocultar').hide();
        var enlace = $(this).attr('href');
        $(enlace).fadeIn();

        return false;
    });

    /* ************************ ANIMACIÓN PARA LOS NÚMEROS *************************** */

    var resumenLista = jQuery('.resumen-evento');
    if(resumenLista.length>0){
        $('.resumen-evento').waypoint(function(){
            $('ul.resumen-evento li:nth-child(1) p').animateNumber({number: 6}, 1300); // el número 6, es el número hasta donde llega, y el 1200 es la velocidad
            $('ul.resumen-evento li:nth-child(2) p').animateNumber({number: 15}, 1500);
            $('ul.resumen-evento li:nth-child(3) p').animateNumber({number: 3}, 1300);
            $('ul.resumen-evento li:nth-child(4) p').animateNumber({number: 9}, 1300);
        }, {
            offset: '60%'
        });
    }

    
    /* ************************ CUENTA REGRESIVA ************************ */

    $('.cuenta-regresiva').countdown('2019/07/19 01:00:00', function (event) {
        $('#dias').html(event.strftime('%D'));
        $('#horas').html(event.strftime('%H'));
        $('#minutos').html(event.strftime('%M'));
        $('#segundos').html(event.strftime('%S'));
    });

    // COLORBOX clase 364
    
    $('.invitado-info').colorbox({inline:true, width:"60%"});
    $('.boton_newsletter').colorbox({inline:true, width:"60%"});

});